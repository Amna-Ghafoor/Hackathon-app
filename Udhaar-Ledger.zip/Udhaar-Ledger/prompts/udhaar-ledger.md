---
name: udhaar-ledger
description: Turns a small shopkeeper's spoken or typed notes about credit (udhaar) into clean ledger entries and polite payment reminders. Use this skill whenever the input is informal bookkeeping speech or text in Urdu, Roman Urdu, Punjabi, Hindi, English, or a mix of them, such as "Ali ne 500 udhaar liya" or "Bilal ne 200 wapis diye". Also use it when asked to summarize who owes what or to write a reminder message for a customer who owes money, even if the user does not say "ledger".
license: MIT
---

# Udhaar Ledger

This skill converts messy, mixed-language shop talk into structured ledger entries, and turns balances into polite reminder messages. It is built for small shopkeepers who keep credit records in a paper notebook.

## When to use

- The user dictates or types one or more credit or payment events in casual speech.
- The user asks for a balance summary or a list of who owes money.
- The user asks for a reminder message for one or more customers.

## Step 1: Parse entries

Read the input and extract every event as one entry.

Each entry has these fields:

| Field | Meaning |
|---|---|
| `customer` | Name as spoken, normalized to one consistent spelling per person (for example "Ali", "Ali bhai" and "Ali sahab" are all "Ali") |
| `type` | `credit` if the customer took goods or money on credit, `payment` if the customer paid back |
| `amount` | A number, in rupees, with no symbols or commas |
| `note` | Optional short item description, such as "sugar" or "mobile load". Empty string if none |
| `confidence` | `high`, `medium` or `low` |

### Vocabulary hints

Credit words: udhaar, udhar, liya, le gaya, baqaya, likh lo, khaata, کھاتہ, ادھار, उधार.
Payment words: wapis, wapas, diye, de diye, jama, clear, ادا, واپس, वापस.

### Number handling

- Understand spoken numbers in any of the supported languages, for example "paanch sau" is 500, "dedh hazaar" is 1500, "dhai sau" is 250, "sawa sau" is 125.
- Treat "k" and "hazaar" as thousand.
- If an amount is missing or unclear, set `confidence` to `low` and set `amount` to 0. Never guess an amount.

## Step 2: Update balances

- Balance per customer = total `credit` minus total `payment`.
- A positive balance means the customer owes the shopkeeper.
- A negative balance means the customer overpaid. Show it as an advance and flag it for the shopkeeper to check.
- Never invent customers, amounts or dates that are not in the input.

## Step 3: Reminder messages (only when asked)

For each customer who owes money, write one short, polite reminder.

Rules:
- Write in the language the shopkeeper uses (default: Roman Urdu).
- Always include the customer's name and the exact amount owed.
- Keep it warm and respectful. Never threaten, shame or pressure.
- Keep it under 3 sentences so it fits a WhatsApp message.
- Do not mention other customers' names or balances.

Example (Roman Urdu):
"Salam Ali bhai, umeed hai aap khairiyat se hain. Aap ka 1,300 rupay baqaya hai, jab suhulat ho ada kar dijiye ga. Shukriya!"

## Output format

When parsing, return only valid JSON with no extra text and no markdown fences:

```json
{
  "entries": [
    { "customer": "Ali", "type": "credit", "amount": 500, "note": "", "confidence": "high" },
    { "customer": "Bilal", "type": "payment", "amount": 200, "note": "", "confidence": "high" }
  ],
  "needs_review": ["Short description of anything unclear, or empty list"]
}
```

When writing reminders, return only valid JSON:

```json
{
  "reminders": [
    { "customer": "Ali", "amount_owed": 1300, "message": "Salam Ali bhai, ..." }
  ]
}
```

## Safety and privacy rules

- Only use information given in the current input and the ledger data passed to you.
- If the input is not about shop credit or payments, return an empty `entries` list and explain in `needs_review`.
- Do not store, guess or reveal phone numbers or personal details that were not provided.
- The shopkeeper always has the final say. Anything with `low` confidence must be shown to them for confirmation before it is saved.

## Examples

Input: "Ali ne 500 udhaar liya, Bilal ne 200 wapis diye"
Output entries: Ali credit 500, Bilal payment 200.

Input: "Sara baji ne dedh hazaar ka rashan liya"
Output entries: Sara credit 1500, note "rashan".

Input: "Usman ne kuch paise diye"
Output entries: Usman payment, amount 0, confidence low, and `needs_review` says the amount was not clear.
