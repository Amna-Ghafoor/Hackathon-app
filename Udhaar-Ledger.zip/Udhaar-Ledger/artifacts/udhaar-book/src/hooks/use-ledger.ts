import { useCallback, useEffect, useMemo, useState } from 'react';

export type EntryType = 'credit' | 'payment';
export type Confidence = 'high' | 'medium' | 'low';
export type LedgerEntry = { id: string; customer: string; type: EntryType; amount: number; note: string; confidence: Confidence; createdAt: string };
export type Preferences = { theme: 'light' | 'dark' | 'system'; reminderLanguage: 'roman_urdu' | 'urdu' | 'english' };
const KEY = 'udhaar-book-ledger-v1';
const PREF_KEY = 'udhaar-book-preferences-v1';
const normalizeKey = (value: string) => value.trim().replace(/\s+/g, ' ').toLocaleLowerCase();
const normalizeName = (value: string) => value.trim().replace(/\s+/g, ' ');

function readLedger(): LedgerEntry[] {
  try { const raw = localStorage.getItem(KEY); return raw ? JSON.parse(raw) as LedgerEntry[] : []; } catch { return []; }
}
function readPreferences(): Preferences {
  try { return { theme: 'system', reminderLanguage: 'roman_urdu', ...JSON.parse(localStorage.getItem(PREF_KEY) || '{}') }; } catch { return { theme: 'system', reminderLanguage: 'roman_urdu' }; }
}
export function useLedger() {
  const [entries, setEntries] = useState<LedgerEntry[]>(readLedger);
  const [preferences, setPreferencesState] = useState<Preferences>(readPreferences);
  useEffect(() => { localStorage.setItem(KEY, JSON.stringify(entries)); }, [entries]);
  useEffect(() => { localStorage.setItem(PREF_KEY, JSON.stringify(preferences)); }, [preferences]);
  const setPreferences = useCallback((updates: Partial<Preferences>) => setPreferencesState((p) => ({ ...p, ...updates })), []);
  const addEntries = useCallback((items: Omit<LedgerEntry, 'id' | 'createdAt'>[]) => {
    const now = new Date().toISOString();
    const next = items.map((item) => ({ ...item, customer: normalizeName(item.customer), id: crypto.randomUUID(), createdAt: now }));
    setEntries((prev) => [...next, ...prev]);
    return next;
  }, []);
  const removeEntry = useCallback((id: string) => setEntries((prev) => prev.filter((e) => e.id !== id)), []);
  const clear = useCallback(() => setEntries([]), []);
  const balances = useMemo(() => {
    const grouped = new Map<string, { customer: string; credit: number; paid: number; count: number }>();
    entries.forEach((entry) => {
      const key = normalizeKey(entry.customer);
      const row = grouped.get(key) || { customer: normalizeName(entry.customer), credit: 0, paid: 0, count: 0 };
      if (entry.type === 'credit') row.credit += entry.amount; else row.paid += entry.amount;
      row.count += 1; grouped.set(key, row);
    });
    return [...grouped.values()].map((row) => ({ ...row, owed: row.credit - row.paid })).sort((a, b) => b.owed - a.owed);
  }, [entries]);
  const outstanding = balances.reduce((sum, b) => sum + Math.max(0, b.owed), 0);
  const customersOwing = balances.filter((b) => b.owed > 0).length;
  const undoLastSave = useCallback((ids: string[]) => setEntries((prev) => prev.filter((entry) => !ids.includes(entry.id))), []);
  return { entries, setEntries, addEntries, removeEntry, clear, balances, outstanding, customersOwing, preferences, setPreferences, undoLastSave };
}
