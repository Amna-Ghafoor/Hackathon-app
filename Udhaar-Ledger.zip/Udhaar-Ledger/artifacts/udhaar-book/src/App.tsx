import { useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter, Link } from 'wouter';
import { useGenerateLedgerReminders, useParseLedgerEntries } from '@workspace/api-client-react';
import { ArrowDownLeft, ArrowRight, ArrowUpRight, BookOpen, Check, CheckCircle2, ChevronDown, CircleAlert, Clipboard, Download, FileText, History, Languages, LoaderCircle, Mic, Moon, MoreHorizontal, Plus, RotateCcw, Settings, ShieldCheck, Sun, Trash2, Users, Volume2, Wallet, X } from '@/components/icons';
import { type Confidence, type EntryType, type LedgerEntry, useLedger } from '@/hooks/use-ledger';

const queryClient = new QueryClient();
const DEMO_TEXT = 'Ali ne 500 udhaar liya, Bilal ne 200 wapis diye, Sara baji ne dedh hazaar ka rashan liya, Ali ne 800 ka aur saman liya';
const money = (value: number) => `Rs ${Math.abs(value).toLocaleString('en-PK', { maximumFractionDigits: 0 })}`;
const confidenceLabel = (value: string) => value === 'high' ? 'Clear' : value === 'medium' ? 'Check details' : 'Needs review';
type ParsedEntry = { customer: string; type: EntryType; amount: number; note: string; confidence: Confidence; approved: boolean; changed: boolean };
type ReminderDraft = { customer: string; amount_owed: number; message: string };
type SpeechLike = { lang: string; interimResults: boolean; continuous: boolean; onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null; onend: (() => void) | null; onerror: (() => void) | null; start: () => void; stop: () => void };
type WindowSpeech = Window & { SpeechRecognition?: new () => SpeechLike; webkitSpeechRecognition?: new () => SpeechLike };

function formatDate(date: string) {
  const d = new Date(date);
  const today = new Date();
  const yesterday = new Date(); yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return d.toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' });
}
function typeName(type: EntryType) { return type === 'credit' ? 'Udhaar' : 'Wapis'; }
function TypeBadge({ type }: { type: EntryType }) {
  return <span className={`type-badge ${type}`}><span>{type === 'credit' ? <ArrowUpRight size={14} /> : <ArrowDownLeft size={14} />}</span>{typeName(type)}</span>;
}
function Avatar({ name, small = false }: { name: string; small?: boolean }) {
  return <span className={`avatar ${small ? 'avatar-small' : ''}`} aria-hidden="true">{name.trim().slice(0, 1).toLocaleUpperCase() || '?'}</span>;
}
function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}
function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch>
    <Route path="/"><BookApp page="home" /></Route>
    <Route path="/hisaab"><BookApp page="balances" /></Route>
    <Route path="/reminders"><BookApp page="reminders" /></Route>
    <Route path="/history"><BookApp page="history" /></Route>
    <Route component={NotFound} />
  </Switch></ErrorBoundary>;
}
function BookApp({ page }: { page: 'home' | 'balances' | 'reminders' | 'history' }) {
  const ledger = useLedger();
  const parseMutation = useParseLedgerEntries();
  const reminderMutation = useGenerateLedgerReminders();
  const [transcript, setTranscript] = useState('');
  const [review, setReview] = useState<ParsedEntry[]>([]);
  const [needsReview, setNeedsReview] = useState<string[]>([]);
  const [listening, setListening] = useState(false);
  const [speechLanguage, setSpeechLanguage] = useState<'ur-PK' | 'hi-IN' | 'en-IN'>('ur-PK');
  const [speechNotice, setSpeechNotice] = useState('');
  const [toast, setToast] = useState<{ message: string; undo?: () => void } | null>(null);
  const [reminders, setReminders] = useState<ReminderDraft[]>([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<'clear' | { deleteId: string } | null>(null);
  const [filter, setFilter] = useState('');
  const speechRef = useRef<SpeechLike | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);
  const notify = (message: string, undo?: () => void) => {
    setToast({ message, undo });
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 5000);
  };
  const navItems = [
    { href: '/', label: 'Bolo', icon: Volume2, page: 'home' },
    { href: '/hisaab', label: 'Hisaab', icon: Wallet, page: 'balances' },
    { href: '/reminders', label: 'Reminders', icon: Clipboard, page: 'reminders' },
    { href: '/history', label: 'History', icon: History, page: 'history' },
  ] as const;
  const title = page === 'home' ? 'Aaj ka hisaab' : page === 'balances' ? 'Customer balances' : page === 'reminders' ? 'Gentle reminders' : 'Ledger history';
  useEffect(() => {
    const root = document.documentElement;
    const applyTheme = () => {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      root.classList.toggle('dark', ledger.preferences.theme === 'dark' || (ledger.preferences.theme === 'system' && prefersDark));
    };
    applyTheme();
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    media.addEventListener?.('change', applyTheme);
    return () => media.removeEventListener?.('change', applyTheme);
  }, [ledger.preferences.theme]);
  useEffect(() => () => { if (speechRef.current) speechRef.current.stop(); window.clearTimeout(toastTimer.current); }, []);

  const parseTranscript = () => {
    if (!transcript.trim()) { notify('Add a few words first, then we’ll make sense of them.'); return; }
    parseMutation.mutate({ data: { text: transcript.trim() } }, {
      onSuccess: (result) => {
        setReview(result.entries.map((entry) => ({ ...entry, customer: entry.customer.trim(), note: entry.note || '', approved: entry.confidence === 'high' && entry.amount > 0, changed: false })));
        setNeedsReview(result.needs_review || []);
        if (!result.entries.length) notify('We couldn’t find a clear entry. Try adding a name or amount.');
        else notify(`${result.entries.length} ${result.entries.length === 1 ? 'entry' : 'entries'} ready for your review.`);
      },
      onError: () => notify('Couldn’t understand that just yet. Please try again.'),
    });
  };
  const toggleListening = () => {
    if (listening) { speechRef.current?.stop(); setListening(false); return; }
    const Speech = (window as WindowSpeech).SpeechRecognition || (window as WindowSpeech).webkitSpeechRecognition;
    if (!Speech) { setSpeechNotice('Voice input is not available in this browser. You can type your entry below.'); return; }
    const recognition = new Speech();
    recognition.lang = speechLanguage; recognition.interimResults = true; recognition.continuous = true;
    recognition.onresult = (event) => {
      let words = '';
      for (let index = 0; index < event.results.length; index += 1) words += `${event.results[index][0].transcript} `;
      setTranscript(words.trim());
    };
    recognition.onerror = () => { setListening(false); setSpeechNotice('We lost the voice connection. Your typed notes are still here.'); };
    recognition.onend = () => setListening(false);
    speechRef.current = recognition;
    try { recognition.start(); setListening(true); setSpeechNotice(''); } catch { setSpeechNotice('Microphone could not start. Please check browser permission.'); }
  };
  const updateReview = (index: number, updates: Partial<ParsedEntry>) => setReview((prev) => prev.map((entry, i) => i === index ? { ...entry, ...updates, changed: true, approved: true } : entry));
  const confirmEntry = (index: number) => setReview((prev) => prev.map((item, i) => i === index ? { ...item, approved: true } : item));
  const saveReviewed = () => {
    const approved = review.filter((entry) => entry.approved && entry.customer.trim() && entry.amount > 0);
    if (!approved.length) { notify('Review and approve at least one complete entry before saving.'); return; }
    const saved = ledger.addEntries(approved.map(({ customer, type, amount, note, confidence }) => ({ customer, type, amount: Number(amount), note, confidence })));
    setReview((prev) => prev.filter((item) => !item.approved));
    setNeedsReview([]);
    setTranscript('');
    notify(`${saved.length} ${saved.length === 1 ? 'entry' : 'entries'} saved to this device.`, () => {
      ledger.undoLastSave(saved.map((entry) => entry.id));
      setToast(null);
    });
  };
  const generateReminders = () => {
    const owing = ledger.balances.filter((balance) => balance.owed > 0).map(({ customer, owed }) => ({ customer, amount_owed: owed }));
    if (!owing.length) { notify('No outstanding balances to remind just now.'); return; }
    reminderMutation.mutate({ data: { balances: owing, language: ledger.preferences.reminderLanguage } }, {
      onSuccess: (result) => { setReminders(result.reminders); notify(`${result.reminders.length} private reminder drafts are ready.`); },
      onError: () => notify('Couldn’t prepare reminders. Please try again.'),
    });
  };
  const exportCsv = () => {
    if (!ledger.entries.length) { notify('Your ledger is empty, so there is nothing to export yet.'); return; }
    const quote = (value: string | number) => `"${String(value).replaceAll('"', '""')}"`;
    const rows = [['Customer', 'Type', 'Amount', 'Note', 'Confidence', 'Date'], ...ledger.entries.map((entry) => [entry.customer, typeName(entry.type), entry.amount, entry.note, entry.confidence, entry.createdAt])];
    const blob = new Blob([rows.map((row) => row.map(quote).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob); const anchor = document.createElement('a');
    anchor.href = url; anchor.download = `udhaar-ledger-${new Date().toISOString().slice(0, 10)}.csv`; anchor.click(); URL.revokeObjectURL(url);
    setMenuOpen(false); notify('Ledger exported as a CSV file.');
  };
  const filteredEntries = useMemo(() => ledger.entries.filter((entry) => `${entry.customer} ${entry.note} ${typeName(entry.type)}`.toLowerCase().includes(filter.toLowerCase())), [ledger.entries, filter]);
  const grouped = useMemo(() => {
    const groups = new Map<string, LedgerEntry[]>();
    filteredEntries.forEach((entry) => { const key = formatDate(entry.createdAt); groups.set(key, [...(groups.get(key) || []), entry]); });
    return [...groups.entries()];
  }, [filteredEntries]);
  const deleteEntry = (id: string) => { ledger.removeEntry(id); setConfirmDialog(null); notify('Entry removed from your ledger.'); };
  const confirmClear = () => { ledger.clear(); setReminders([]); setConfirmDialog(null); setMenuOpen(false); notify('All ledger entries have been cleared from this device.'); };

  return <div className="app-frame">
    <header className="mobile-top paper-header">
      <Link href="/" className="brand-mark" data-testid="link-brand-mobile"><span className="brand-icon"><BookOpen size={20} /></span><span><strong>Udhaar Book</strong><small>Bol kar likhein</small></span></Link>
      <button className="icon-button" aria-label="Open settings" data-testid="button-settings-mobile" onClick={() => setMenuOpen(!menuOpen)}><MoreHorizontal size={21} /></button>
    </header>
    <div className="workspace">
      <aside className="sidebar">
        <Link href="/" className="brand-mark" data-testid="link-brand"><span className="brand-icon"><BookOpen size={21} /></span><span><strong>Udhaar Book</strong><small>Bol kar likhein</small></span></Link>
        <div className="shop-label">YOUR KHAATA <span>LOCAL</span></div>
        <nav className="side-nav" aria-label="Main navigation">
          {navItems.map(({ href, label, icon: Icon, page: navPage }) => <Link href={href} key={href} className={`nav-link ${page === navPage ? 'active' : ''}`} data-testid={`link-nav-${navPage}`}><Icon size={18} strokeWidth={1.9} /><span>{label}</span>{page === navPage && <span className="nav-dot" />}</Link>)}
        </nav>
        <div className="sidebar-bottom">
          <div className="device-note"><ShieldCheck size={17} /><span>Only on this device</span></div>
          <button className="settings-trigger" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} data-testid="button-settings"><Settings size={17} /><span>Settings</span><ChevronDown size={15} /></button>
          {menuOpen && <div className="settings-menu">
            <p>Preferences</p>
            <button onClick={() => ledger.setPreferences({ theme: ledger.preferences.theme === 'dark' ? 'light' : 'dark' })} data-testid="button-theme"><span>{ledger.preferences.theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />} Appearance</span><small>{ledger.preferences.theme === 'dark' ? 'Dark' : 'Light'}</small></button>
            <button onClick={exportCsv} data-testid="button-export"><span><Download size={16} /> Export ledger (CSV)</span></button>
            <button className="danger-action" onClick={() => setConfirmDialog('clear')} data-testid="button-clear"><span><Trash2 size={16} /> Clear all data</span></button>
          </div>}
          <div className="avatar-profile"><Avatar name="K" small /><span><b>Your shop</b><small>Personal khaata</small></span><span className="local-indicator" /></div>
        </div>
      </aside>
      <main className="main-content">
        <div className="mobile-menu-wrap">{menuOpen && <div className="settings-menu mobile-settings"><p>Preferences</p><button onClick={() => ledger.setPreferences({ theme: ledger.preferences.theme === 'dark' ? 'light' : 'dark' })}><span>{ledger.preferences.theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />} Appearance</span><small>{ledger.preferences.theme === 'dark' ? 'Dark' : 'Light'}</small></button><button onClick={exportCsv}><span><Download size={16} /> Export ledger (CSV)</span></button><button className="danger-action" onClick={() => setConfirmDialog('clear')}><span><Trash2 size={16} /> Clear all data</span></button></div>}</div>
        <div className="content-inner">
          <div className="page-heading"><div><div className="eyebrow">YOUR DAILY KHAATA <span className="eyebrow-dot" /> {new Date().toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' }).toUpperCase()}</div><h1>{title}</h1><p>{page === 'home' ? 'Say it as it happened. We’ll keep the numbers straight.' : page === 'balances' ? 'A clear picture of what is owed and what has come back.' : page === 'reminders' ? 'A kind nudge, ready when you are.' : 'Every entry, just as you recorded it.'}</p></div>
            <button className="desktop-settings icon-button" aria-label="Settings" onClick={() => setMenuOpen(!menuOpen)} data-testid="button-settings-heading"><MoreHorizontal size={20} /></button>
          </div>
          <section className="summary-strip" aria-label="Outstanding summary" data-testid="summary-outstanding">
            <div className="summary-copy"><span className="summary-kicker"><ArrowUpRight size={13} /><span className="sunny-mark" /> TOTAL UDHAAR OUTSTANDING</span><div className="summary-amount">{money(ledger.outstanding)}</div><div className="summary-foot">{ledger.customersOwing} {ledger.customersOwing === 1 ? 'customer owes' : 'customers owe'} you</div></div>
            <div className="summary-art" aria-hidden="true"><span className="art-page page-one" /><span className="art-page page-two" /><span className="art-circle"><BookOpen size={26} /></span></div>
            <span className="summary-caption">Your numbers, in one place.</span>
          </section>
          {page === 'home' && <section className="home-layout enter">
            <div className="home-main">
              <div className="section-title-row"><div><span className="section-index">01</span><h2>Say it your way</h2></div><span className="language-note"><Languages size={15} /> Urdu · Roman Urdu · Punjabi · Hindi · English</span></div>
              <div className="soft-card voice-card">
                <div className="voice-card-top"><span className="live-label"><span className="status-dot" /> {listening ? 'LISTENING' : 'VOICE NOTE'}</span><span className="private-label"><ShieldCheck size={14} /> Private on this device</span></div>
                <div className="mic-area">
                  <button className={`mic-button ${listening ? 'listening' : ''}`} onClick={toggleListening} aria-label={listening ? 'Stop recording' : 'Start voice recording'} aria-pressed={listening} data-testid="button-microphone">
                    {listening && <span className="mic-pulse" />}{listening ? <Volume2 size={27} /> : <Mic size={27} />}
                  </button>
                  <div className="mic-caption">{listening ? 'Sun raha hoon...' : 'Tap to speak'}</div>
                  <div className={`waveform ${listening ? 'on' : ''}`} aria-hidden="true">{Array.from({ length: 21 }, (_, i) => <span key={i} className="wave-bar" style={{ height: `${9 + ((i * 17) % 22)}px` }} />)}</div>
                </div>
                <div className="speech-languages" role="group" aria-label="Voice recognition language">{([{ code: 'ur-PK', label: 'Urdu' }, { code: 'hi-IN', label: 'Hindi' }, { code: 'en-IN', label: 'English' }] as const).map(({ code, label }) => <button key={code} type="button" className={speechLanguage === code ? 'selected' : ''} aria-pressed={speechLanguage === code} onClick={() => setSpeechLanguage(code)} data-testid={`button-speech-${code}`}>{label}<span>{code}</span></button>)}</div>
                <label className="transcript-label" htmlFor="transcript">YOUR WORDS <span>EDIT ANYTIME</span></label>
                <textarea id="transcript" value={transcript} onChange={(event) => setTranscript(event.target.value)} placeholder="Misal: Ali ne 500 udhaar liya..." rows={4} data-testid="input-transcript" />
                {speechNotice && <div className="inline-notice" role="status"><CircleAlert size={15} />{speechNotice}</div>}
                <div className="voice-actions">
                  <button className="text-button" onClick={() => { setTranscript(DEMO_TEXT); setReview([]); setNeedsReview([]); }} data-testid="button-demo"><FileText size={15} /> Load demo data</button>
                  <button className="button-primary" onClick={parseTranscript} disabled={parseMutation.isPending || !transcript.trim()} data-testid="button-parse">{parseMutation.isPending ? <><LoaderCircle className="spin" size={17} /> Making sense…</> : <>Review entries <ArrowRight size={16} /></>}</button>
                </div>
              </div>
              {parseMutation.isPending && <div className="soft-card parsing-card"><div className="skeleton-line w35" /><div className="skeleton-entry"><span className="skeleton-avatar shimmer" /><div><div className="skeleton-line w50 shimmer" /><div className="skeleton-line w75 shimmer" /></div><div className="skeleton-line w20 shimmer" /></div><div className="skeleton-entry"><span className="skeleton-avatar shimmer" /><div><div className="skeleton-line w40 shimmer" /><div className="skeleton-line w65 shimmer" /></div><div className="skeleton-line w20 shimmer" /></div></div>}
              {needsReview.length > 0 && <div className="review-hints" role="status"><CircleAlert size={17} /><div><b>A little more detail would help</b><ul>{needsReview.map((hint, i) => <li key={`${hint}-${i}`}>{hint}</li>)}</ul></div></div>}
              {review.length > 0 && <div className="review-section enter"><div className="section-title-row review-heading"><div><span className="section-index">02</span><h2>Check before saving</h2></div><span className="review-count">{review.length} {review.length === 1 ? 'entry' : 'entries'}</span></div>
                <div className="review-list">{review.map((entry, index) => <ReviewCard key={`${index}-${entry.customer}`} entry={entry} index={index} onChange={(updates) => updateReview(index, updates)} onApprove={() => confirmEntry(index)} onRemove={() => setReview((prev) => prev.filter((_, i) => i !== index))} />)}</div>
                <div className="save-review-row"><span><ShieldCheck size={16} /> Nothing is saved until you confirm it.</span><button className="button-primary" onClick={saveReviewed} data-testid="button-save-entries"><Check size={17} /> Save confirmed {review.some((entry) => entry.approved) ? `(${review.filter((entry) => entry.approved).length})` : ''}</button></div>
              </div>}
              {review.length === 0 && !parseMutation.isPending && <div className="privacy-note"><ShieldCheck size={16} /><span>Your voice note is used to prepare a suggestion. Only entries you confirm are saved here.</span></div>}
            </div>
            <aside className="home-aside">
              <div className="aside-heading"><span className="section-index">TODAY</span><span>AT A GLANCE</span></div>
              <div className="soft-card glance-card">
                <div className="glance-top"><span className="glance-icon coral-bg"><ArrowUpRight size={17} /></span><span>Still owed</span></div><strong className="glance-value coral-text">{money(ledger.outstanding)}</strong><div className="glance-bottom">{ledger.customersOwing} customers with a balance</div>
                <div className="glance-rule" />
                <div className="glance-top"><span className="glance-icon sage-bg"><ArrowDownLeft size={17} /></span><span>Wapis · Received back</span></div><strong className="glance-value sage-text">{money(ledger.entries.filter((entry) => entry.type === 'payment').reduce((n, e) => n + e.amount, 0))}</strong><div className="glance-bottom">Across {ledger.entries.length} saved {ledger.entries.length === 1 ? 'entry' : 'entries'}</div>
                <Link href="/hisaab" className="aside-link" data-testid="link-all-balances">See all balances <ArrowRight size={15} /></Link>
              </div>
              <div className="help-note"><span className="help-stamp"><BookOpen size={17} /></span><div><b>A note from your khaata</b><p>Say the amount and the name. We’ll make a suggestion, you stay in charge.</p></div></div>
              <p className="device-footer"><ShieldCheck size={14} /> Your ledger is saved only on this device.</p>
            </aside>
          </section>}
          {page === 'balances' && <section className="page-body enter">
            <div className="balances-topline"><div className="balance-total"><small>NET OUTSTANDING</small><strong>{money(ledger.outstanding)}</strong></div><div className="balance-count"><Users size={17} /><span>{ledger.balances.length} {ledger.balances.length === 1 ? 'customer' : 'customers'} in your khaata</span></div></div>
            {ledger.balances.length === 0 ? <EmptyState title="A clean page, for now." text="Once you confirm an udhaar or wapis entry, each customer’s balance will appear here." icon="balance" /> : <div className="balance-list">{ledger.balances.map((balance, index) => <div className="soft-card balance-card" key={balance.customer.toLocaleLowerCase()} data-testid={`card-balance-${index}`}>
              <Avatar name={balance.customer} /><div className="balance-customer"><strong>{balance.customer}</strong><span>{balance.count} {balance.count === 1 ? 'entry' : 'entries'} recorded</span><div className="balance-track"><span style={{ width: `${Math.max(8, Math.min(100, balance.credit / Math.max(balance.credit + balance.paid, 1) * 100))}%` }} /></div><div className="balance-legend"><span><ArrowUpRight size={12} /> Udhaar {money(balance.credit)}</span><span><ArrowDownLeft size={12} /> Wapis {money(balance.paid)}</span></div></div>
              <div className="balance-owed">{balance.owed < 0 ? <><strong className="sage-text">{money(balance.owed)}</strong><span className="advance-badge"><ArrowDownLeft size={12} /> Wapis · Advance</span><small>Please check</small></> : <><strong className="coral-text">{money(balance.owed)}</strong><span className="balance-status"><ArrowUpRight size={12} /> Udhaar · Owes you</span></>}</div>
            </div>)}</div>}
            <p className="privacy-line"><ShieldCheck size={15} /> Balances are calculated from the entries saved on this device.</p>
          </section>}
          {page === 'reminders' && <section className="page-body enter">
            <div className="reminder-intro soft-card"><div className="reminder-stamp"><Clipboard size={20} /></div><div><h2>A kind word goes a long way.</h2><p>Drafts are private. You choose who to send them to in WhatsApp.</p></div><ShieldCheck size={17} /></div>
            <div className="reminder-controls"><div className="language-segment" aria-label="Reminder language">
              {([{ key: 'roman_urdu', label: 'Roman Urdu' }, { key: 'urdu', label: 'اردو' }, { key: 'english', label: 'English' }] as const).map(({ key, label }) => <button key={key} onClick={() => ledger.setPreferences({ reminderLanguage: key })} className={ledger.preferences.reminderLanguage === key ? 'selected' : ''} aria-pressed={ledger.preferences.reminderLanguage === key} data-testid={`button-language-${key}`}>{label}</button>)}
            </div><button className="button-primary" onClick={generateReminders} disabled={reminderMutation.isPending || !ledger.customersOwing} data-testid="button-generate-reminders">{reminderMutation.isPending ? <><LoaderCircle className="spin" size={17} /> Preparing…</> : <><Plus size={17} /> Generate reminders</>}</button></div>
            <div className="no-phone-note"><ShieldCheck size={15} /> No phone numbers are asked for or stored. WhatsApp lets you pick the contact.</div>
            {reminderMutation.isPending && <div className="reminder-skeleton"><div className="soft-card shimmer" /><div className="soft-card shimmer" /></div>}
            {reminders.length > 0 && <div className="reminder-list">{reminders.map((reminder, index) => <div className="soft-card reminder-card" key={`${reminder.customer}-${index}`}>
              <div className="reminder-person"><Avatar name={reminder.customer} small /><div><strong>{reminder.customer}</strong><small>Udhaar balance <b>{money(reminder.amount_owed)}</b></small></div><span className="draft-status">DRAFT</span></div>
              <div className={`chat-bubble ${ledger.preferences.reminderLanguage === 'urdu' ? 'urdu-text' : ''}`} dir={ledger.preferences.reminderLanguage === 'urdu' ? 'rtl' : 'auto'}><textarea aria-label={`Edit reminder for ${reminder.customer}`} value={reminder.message} onChange={(event) => setReminders((prev) => prev.map((item, i) => i === index ? { ...item, message: event.target.value } : item))} rows={3} data-testid={`input-reminder-${index}`} /><span className="bubble-time">Just now</span></div>
              <div className="reminder-actions"><button className="button-secondary" onClick={async () => { try { await navigator.clipboard.writeText(reminder.message); notify('Reminder copied to clipboard.'); } catch { notify('Clipboard access is unavailable in this browser.'); } }} data-testid={`button-copy-${index}`}><Clipboard size={16} /> Copy</button><button className="whatsapp-button" onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(reminder.message)}`, '_blank', 'noopener,noreferrer')} data-testid={`button-whatsapp-${index}`}><span className="whatsapp-glyph">W</span> Send on WhatsApp <ArrowRight size={15} /></button></div>
            </div>)}</div>}
            {!reminders.length && !reminderMutation.isPending && <EmptyState title={ledger.customersOwing ? 'Ready when you are.' : 'No one to nudge just yet.'} text={ledger.customersOwing ? 'Choose a language, then generate a private draft for customers with an outstanding balance.' : 'When a customer has a positive balance, you can write them a gentle reminder here.'} icon="reminder" />}
          </section>}
          {page === 'history' && <section className="page-body enter">
            <div className="history-toolbar"><div className="history-count"><strong>{ledger.entries.length}</strong><span>saved {ledger.entries.length === 1 ? 'entry' : 'entries'}</span></div><label className="search-box"><span className="sr-only">Filter entries</span><input value={filter} onChange={(event) => setFilter(event.target.value)} placeholder="Find a name or note" data-testid="input-history-search" /><span className="search-symbol">⌕</span></label></div>
            {grouped.length === 0 ? <EmptyState title={filter ? 'No matching entries.' : 'Your history starts here.'} text={filter ? 'Try a different name or clear your search.' : 'Confirmed entries appear here, grouped by the day they were saved.'} icon="history" /> : <div className="timeline">{grouped.map(([day, items]) => <div className="timeline-group" key={day}><div className="timeline-day"><span className="timeline-pin" /><h2>{day}</h2><span>{items.length} {items.length === 1 ? 'entry' : 'entries'}</span></div><div className="timeline-items">{items.map((entry) => <div className="soft-card history-row" key={entry.id} data-testid={`row-entry-${entry.id}`}><span className={`history-arrow ${entry.type}`}>{entry.type === 'credit' ? <ArrowUpRight size={17} /> : <ArrowDownLeft size={17} />}</span><div className="history-info"><strong>{entry.customer}</strong><span>{entry.note || typeName(entry.type)} <i>·</i> {new Date(entry.createdAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span></div><TypeBadge type={entry.type} /><strong className={`history-amount ${entry.type}`}>{entry.type === 'credit' ? '+' : '−'}{money(entry.amount)}</strong><button className="row-delete" aria-label={`Delete entry for ${entry.customer}`} onClick={() => setConfirmDialog({ deleteId: entry.id })} data-testid={`button-delete-entry-${entry.id}`}><Trash2 size={16} /></button></div>)}</div></div>)}</div>}
            {ledger.entries.length > 0 && <button className="undo-history" onClick={() => { const latest = ledger.entries[0]; if (!latest) return; ledger.removeEntry(latest.id); notify('Last saved entry undone.'); }} data-testid="button-undo-history"><RotateCcw size={15} /> Undo last save</button>}
          </section>}
        </div>
        <footer className="desktop-footer"><ShieldCheck size={14} /> Your ledger is saved only on this device. <span>Udhaar Book</span></footer>
      </main>
    </div>
    <nav className="mobile-tabs" aria-label="Main navigation">{navItems.map(({ href, label, icon: Icon, page: navPage }) => <Link href={href} key={href} className={`mobile-tab ${page === navPage ? 'active' : ''}`} data-testid={`mobile-nav-${navPage}`}><Icon size={19} /><span>{label}</span></Link>)}</nav>
    {toast && <div className="toast-message" role="status" aria-live="polite"><span className="toast-mark"><CheckCircle2 size={17} /></span><span>{toast.message}</span>{toast.undo && <button onClick={toast.undo} data-testid="button-undo-toast">Undo</button>}<button className="toast-close" aria-label="Dismiss notification" onClick={() => setToast(null)}><X size={16} /></button></div>}
    {confirmDialog && <div className="dialog-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setConfirmDialog(null); }}><div className="confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="confirm-title">
      <span className="dialog-icon"><CircleAlert size={22} /></span><h2 id="confirm-title">{confirmDialog === 'clear' ? 'Clear your whole khaata?' : 'Remove this entry?'}</h2><p>{confirmDialog === 'clear' ? 'This removes every saved ledger entry from this device. This cannot be undone.' : 'This entry will be removed from the ledger and the customer balance will update.'}</p><div className="dialog-actions"><button className="button-secondary" onClick={() => setConfirmDialog(null)} data-testid="button-cancel-dialog">Keep it</button><button className="danger-button" onClick={() => confirmDialog === 'clear' ? confirmClear() : deleteEntry(confirmDialog.deleteId)} data-testid="button-confirm-dialog">{confirmDialog === 'clear' ? 'Clear all entries' : 'Remove entry'}</button></div>
    </div></div>}
  </div>;
}
function ReviewCard({ entry, index, onChange, onApprove, onRemove }: { entry: ParsedEntry; index: number; onChange: (updates: Partial<ParsedEntry>) => void; onApprove: () => void; onRemove: () => void }) {
  const caution = !entry.approved || entry.amount <= 0 || entry.confidence === 'low';
  return <article className={`soft-card review-card ${caution ? 'caution' : ''}`} style={{ animationDelay: `${index * 55}ms` }} data-testid={`card-review-${index}`}>
    <div className="review-card-top"><Avatar name={entry.customer || '?'} /><div className="review-name"><input value={entry.customer} onChange={(event) => onChange({ customer: event.target.value })} aria-label="Customer name" placeholder="Customer name" data-testid={`input-review-customer-${index}`} /><span>{confidenceLabel(entry.confidence)} {entry.confidence !== 'high' && <CircleAlert size={13} />}</span></div><TypeBadge type={entry.type} /><button className="subtle-icon" onClick={onRemove} aria-label="Remove suggestion" data-testid={`button-remove-review-${index}`}><X size={17} /></button></div>
    <div className="review-fields"><label className="field-label">ENTRY TYPE<select value={entry.type} onChange={(event) => onChange({ type: event.target.value as EntryType })} data-testid={`select-review-type-${index}`}><option value="credit">Udhaar · Given on credit</option><option value="payment">Wapis · Payment received</option></select></label><label className="field-label amount-field">AMOUNT<input type="number" min="0" value={entry.amount} onChange={(event) => onChange({ amount: Number(event.target.value) })} data-testid={`input-review-amount-${index}`} /></label></div>
    <label className="field-label note-field">NOTE <input value={entry.note} onChange={(event) => onChange({ note: event.target.value })} placeholder="Optional details" data-testid={`input-review-note-${index}`} /></label>
    <div className="review-card-bottom">{caution ? <span className="review-warning"><CircleAlert size={15} /> Please check this entry</span> : <span className="review-ok"><CheckCircle2 size={15} /> Looks clear</span>}
      {caution && !entry.approved ? <button className="approve-button" onClick={onApprove} disabled={!entry.customer.trim() || entry.amount <= 0} data-testid={`button-approve-review-${index}`}><Check size={15} /> Approve</button> : <span className="approved-label"><Check size={14} /> Ready</span>}
    </div>
  </article>;
}
function EmptyState({ title, text, icon }: { title: string; text: string; icon: 'balance' | 'reminder' | 'history' }) {
  const Icon = icon === 'balance' ? Users : icon === 'reminder' ? Clipboard : History;
  return <div className="empty-state soft-card"><div className="empty-illustration"><span className="empty-orbit orbit-one" /><span className="empty-orbit orbit-two" /><span className="empty-book"><Icon size={25} /></span><span className="empty-spark spark-one" /><span className="empty-spark spark-two" /></div><h2>{title}</h2><p>{text}</p></div>;
}
export default App;
