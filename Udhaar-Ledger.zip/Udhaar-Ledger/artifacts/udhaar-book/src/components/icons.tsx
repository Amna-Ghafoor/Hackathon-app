import { type ReactNode } from "react";

type IconProps = {
  size?: number;
  className?: string;
  strokeWidth?: number;
};

const paths = {
  ArrowDownLeft: (
    <>
      <path d="M17 7 7 17" />
      <path d="M7 7v10h10" />
    </>
  ),
  ArrowRight: (
    <>
      <path d="M5 12h14" />
      <path d="m12 5 7 7-7 7" />
    </>
  ),
  ArrowUpRight: (
    <>
      <path d="M7 17 17 7" />
      <path d="M7 7h10v10" />
    </>
  ),
  BookOpen: (
    <>
      <path d="M12 7v14" />
      <path d="M3 18V5a2 2 0 0 1 2-2h3a4 4 0 0 1 4 4 4 4 0 0 1 4-4h3a2 2 0 0 1 2 2v13h-5a4 4 0 0 0-4 3 4 4 0 0 0-4-3H3Z" />
    </>
  ),
  Check: <path d="m5 12 4 4L19 6" />,
  CheckCircle2: (
    <>
      <circle cx="12" cy="12" r="10" />
      <path d="m8 12 2.5 2.5L16 9" />
    </>
  ),
  ChevronDown: <path d="m6 9 6 6 6-6" />,
  CircleAlert: (
    <>
      <circle cx="12" cy="12" r="10" />
      <path d="M12 8v4" />
      <path d="M12 16h.01" />
    </>
  ),
  Clipboard: (
    <>
      <rect x="5" y="4" width="14" height="17" rx="2" />
      <path d="M9 4.5h6a1.5 1.5 0 0 0-3-1.5 1.5 1.5 0 0 0-3 1.5Z" />
      <path d="M9 11h6M9 15h6" />
    </>
  ),
  Download: (
    <>
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <path d="m7 10 5 5 5-5" />
      <path d="M12 15V3" />
    </>
  ),
  FileText: (
    <>
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z" />
      <path d="M14 2v6h6M8 13h8M8 17h8" />
    </>
  ),
  History: (
    <>
      <path d="M3 12a9 9 0 1 0 2.64-6.36L3 8" />
      <path d="M3 3v5h5M12 7v5l3 2" />
    </>
  ),
  Languages: (
    <>
      <path d="m5 8 6 6M4 14l6-6 2-3M2 5h12M7 2h2" />
      <path d="M13 19h8M15 16l2-5 2 5M14 21l3-7 3 7" />
    </>
  ),
  LoaderCircle: (
    <>
      <path d="M21 12a9 9 0 1 1-6.22-8.56" />
    </>
  ),
  Mic: (
    <>
      <rect x="9" y="2" width="6" height="12" rx="3" />
      <path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3M8 22h8" />
    </>
  ),
  Moon: <path d="M20.9 13A9 9 0 0 1 11 3.1 9 9 0 1 0 20.9 13Z" />,
  MoreHorizontal: (
    <>
      <circle cx="5" cy="12" r="1" />
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
    </>
  ),
  Plus: (
    <>
      <path d="M12 5v14M5 12h14" />
    </>
  ),
  RotateCcw: (
    <>
      <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
      <path d="M3 3v5h5M12 7v5l3 2" />
    </>
  ),
  Settings: (
    <>
      <path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z" />
      <path d="m19.4 15 .1.1a2 2 0 0 1-2.8 2.8l-.1-.1a2 2 0 0 0-3.4 1.4v.2a2 2 0 0 1-4 0v-.2a2 2 0 0 0-3.4-1.4l-.1.1a2 2 0 0 1-2.8-2.8l.1-.1a2 2 0 0 0-1.4-3.4h-.2a2 2 0 0 1 0-4h.2a2 2 0 0 0 1.4-3.4l-.1-.1a2 2 0 0 1 2.8-2.8l.1.1a2 2 0 0 0 3.4-1.4v-.2a2 2 0 0 1 4 0v.2a2 2 0 0 0 3.4 1.4l.1-.1a2 2 0 0 1 2.8 2.8l-.1.1a2 2 0 0 0 1.4 3.4h.2a2 2 0 0 1 0 4h-.2a2 2 0 0 0-1.4 3.4Z" />
    </>
  ),
  ShieldCheck: (
    <>
      <path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z" />
      <path d="m9 12 2 2 4-4" />
    </>
  ),
  Sun: (
    <>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42" />
    </>
  ),
  Trash2: (
    <>
      <path d="M3 6h18M8 6V4h8v2m3 0-1 14H6L5 6" />
      <path d="M10 11v5M14 11v5" />
    </>
  ),
  Users: (
    <>
      <path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="10" cy="7" r="4" />
      <path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
    </>
  ),
  Volume2: (
    <>
      <path d="M11 5 6 9H3v6h3l5 4V5Z" />
      <path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14" />
    </>
  ),
  Wallet: (
    <>
      <path d="M4 6.5A2.5 2.5 0 0 1 6.5 4H20v16H6a3 3 0 0 1-3-3V7a.5.5 0 0 1 1 0v10" />
      <path d="M20 9h-5a2 2 0 0 0 0 4h5M15 11h.01" />
    </>
  ),
  X: (
    <>
      <path d="m18 6-12 12M6 6l12 12" />
    </>
  ),
} satisfies Record<string, ReactNode>;

type IconName = keyof typeof paths;

function InlineIcon({
  name,
  size = 20,
  className,
  strokeWidth = 1.8,
}: IconProps & { name: IconName }) {
  return (
    <svg
      aria-hidden="true"
      focusable="false"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      {paths[name]}
    </svg>
  );
}

export const ArrowDownLeft = (props: IconProps) => (
  <InlineIcon name="ArrowDownLeft" {...props} />
);
export const ArrowRight = (props: IconProps) => (
  <InlineIcon name="ArrowRight" {...props} />
);
export const ArrowUpRight = (props: IconProps) => (
  <InlineIcon name="ArrowUpRight" {...props} />
);
export const BookOpen = (props: IconProps) => (
  <InlineIcon name="BookOpen" {...props} />
);
export const Check = (props: IconProps) => <InlineIcon name="Check" {...props} />;
export const CheckCircle2 = (props: IconProps) => (
  <InlineIcon name="CheckCircle2" {...props} />
);
export const ChevronDown = (props: IconProps) => (
  <InlineIcon name="ChevronDown" {...props} />
);
export const CircleAlert = (props: IconProps) => (
  <InlineIcon name="CircleAlert" {...props} />
);
export const Clipboard = (props: IconProps) => (
  <InlineIcon name="Clipboard" {...props} />
);
export const Download = (props: IconProps) => (
  <InlineIcon name="Download" {...props} />
);
export const FileText = (props: IconProps) => (
  <InlineIcon name="FileText" {...props} />
);
export const History = (props: IconProps) => (
  <InlineIcon name="History" {...props} />
);
export const Languages = (props: IconProps) => (
  <InlineIcon name="Languages" {...props} />
);
export const LoaderCircle = (props: IconProps) => (
  <InlineIcon name="LoaderCircle" {...props} />
);
export const Mic = (props: IconProps) => <InlineIcon name="Mic" {...props} />;
export const Moon = (props: IconProps) => <InlineIcon name="Moon" {...props} />;
export const MoreHorizontal = (props: IconProps) => (
  <InlineIcon name="MoreHorizontal" {...props} />
);
export const Plus = (props: IconProps) => <InlineIcon name="Plus" {...props} />;
export const RotateCcw = (props: IconProps) => (
  <InlineIcon name="RotateCcw" {...props} />
);
export const Settings = (props: IconProps) => (
  <InlineIcon name="Settings" {...props} />
);
export const ShieldCheck = (props: IconProps) => (
  <InlineIcon name="ShieldCheck" {...props} />
);
export const Sun = (props: IconProps) => <InlineIcon name="Sun" {...props} />;
export const Trash2 = (props: IconProps) => <InlineIcon name="Trash2" {...props} />;
export const Users = (props: IconProps) => <InlineIcon name="Users" {...props} />;
export const Volume2 = (props: IconProps) => <InlineIcon name="Volume2" {...props} />;
export const Wallet = (props: IconProps) => <InlineIcon name="Wallet" {...props} />;
export const X = (props: IconProps) => <InlineIcon name="X" {...props} />;
