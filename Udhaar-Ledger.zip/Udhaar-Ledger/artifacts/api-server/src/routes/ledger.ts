import { GoogleGenAI } from "@google/genai";
import {
  GenerateLedgerRemindersBody,
  GenerateLedgerRemindersResponse,
  ParseLedgerEntriesBody,
  ParseLedgerEntriesResponse,
} from "@workspace/api-zod";
import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { Router, type IRouter } from "express";
import rateLimit from "express-rate-limit";
import { logger } from "../lib/logger";

const GEMMA_MODEL =
  process.env.GEMMA_MODEL?.trim() || "gemma-4-26b-a4b-it"; // Check the exact model ID in Google AI Studio.

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  throw new Error("GEMINI_API_KEY must be set for the ledger AI routes.");
}

const ai = new GoogleGenAI({ apiKey });

function loadLedgerPrompt(): string {
  let directory = process.cwd();
  for (let depth = 0; depth < 6; depth += 1) {
    const promptPath = resolve(directory, "prompts/udhaar-ledger.md");
    if (existsSync(promptPath)) {
      return readFileSync(promptPath, "utf8");
    }
    const parent = dirname(directory);
    if (parent === directory) break;
    directory = parent;
  }
  throw new Error("Required ledger prompt file was not found.");
}

const LEDGER_SYSTEM_INSTRUCTION = loadLedgerPrompt();
const router: IRouter = Router();
const ledgerLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests. Please wait a moment and try again." },
});

function providerHttpStatus(error: unknown): number | undefined {
  if (
    typeof error === "object" &&
    error !== null &&
    "status" in error &&
    typeof error.status === "number"
  ) {
    return error.status;
  }
  return undefined;
}

function stripMarkdownFence(value: string): string {
  return value
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/, "")
    .trim();
}

async function generateText(contents: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: GEMMA_MODEL,
    contents,
    config: {
      systemInstruction: LEDGER_SYSTEM_INSTRUCTION,
    },
  });
  if (!response.text?.trim()) {
    throw new Error("The model returned an empty response.");
  }
  return stripMarkdownFence(response.text);
}

function toFriendlyReminder(
  customer: string,
  amount: number,
  language: "roman_urdu" | "urdu" | "english",
): string {
  const formattedAmount = new Intl.NumberFormat("en-PK", {
    maximumFractionDigits: 2,
  }).format(amount);

  if (language === "urdu") {
    return `السلام علیکم ${customer}، آپ کے ذمہ ${formattedAmount} روپے باقی ہیں۔ جب سہولت ہو ادا کر دیجیے گا۔ شکریہ!`;
  }
  if (language === "english") {
    return `Hello ${customer}, this is a friendly reminder that Rs ${formattedAmount} is pending. Please settle it when convenient. Thank you!`;
  }
  return `Salam ${customer}, aap ka ${formattedAmount} rupay baqaya hai. Jab suhulat ho ada kar dijiye ga. Shukriya!`;
}

function containsExactAmount(message: string, amount: number): boolean {
  const normalizeDigits = (value: string) =>
    value
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[,\u066c\s]/g, "");

  const normalizedMessage = normalizeDigits(message);
  const amountTokens = normalizedMessage.matchAll(
    /(?<![\d.])\d+(?:\.\d+)?(?![\d.])/g,
  );
  return Array.from(amountTokens).some(([token]) => Number(token) === amount);
}

function containsCustomer(message: string, customer: string): boolean {
  return message.toLocaleLowerCase().includes(customer.trim().toLocaleLowerCase());
}

function mentionsAnotherCustomer(
  message: string,
  currentCustomer: string,
  allCustomers: string[],
): boolean {
  const escapeRegExp = (value: string) =>
    value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const current = currentCustomer.trim().toLocaleLowerCase();

  return allCustomers.some((name) => {
    const candidate = name.trim().toLocaleLowerCase();
    if (!candidate || candidate === current) return false;
    const pattern = new RegExp(
      `(^|[^\\p{L}\\p{N}])${escapeRegExp(candidate)}($|[^\\p{L}\\p{N}])`,
      "iu",
    );
    return pattern.test(message);
  });
}

router.post("/parse", ledgerLimiter, async (req, res): Promise<void> => {
  const input = ParseLedgerEntriesBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: "Couldn't understand that, please try again." });
    return;
  }

  const instruction = `Mode: parse. Return only the entries JSON.\n\n${input.data.text}`;
  let providerFailed = false;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    let text: string;
    try {
      text = await generateText(instruction);
    } catch (error) {
      providerFailed = true;
      req.log.warn(
        {
          errorName: error instanceof Error ? error.name : "UnknownError",
          providerStatus: providerHttpStatus(error),
        },
        "Ledger parse request failed",
      );
      continue;
    }

    try {
      const parsedJson: unknown = JSON.parse(text);
      const result = ParseLedgerEntriesResponse.safeParse(parsedJson);
      if (result.success) {
        res.json(result.data);
        return;
      }
    } catch {
      // Retry malformed model JSON once before returning the friendly error.
    }
  }

  res
    .status(providerFailed ? 500 : 400)
    .json({
      error: providerFailed
        ? "The ledger assistant is unavailable right now. Please try again."
        : "Couldn't understand that, please try again.",
    });
});

router.post("/reminders", ledgerLimiter, async (req, res): Promise<void> => {
  const input = GenerateLedgerRemindersBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: "Please check the balance details and try again." });
    return;
  }

  const balances = input.data.balances.filter(
    (balance) => Number.isFinite(balance.amount_owed) && balance.amount_owed > 0,
  );
  if (balances.length === 0) {
    res.json({ reminders: [] });
    return;
  }

  const customerNames = balances.map((balance) => balance.customer.trim());
  const uniqueCustomerNames = new Set(
    customerNames.map((customer) => customer.toLocaleLowerCase()),
  );
  if (uniqueCustomerNames.size !== customerNames.length) {
    res.status(400).json({
      error: "Please generate reminders for each customer only once.",
    });
    return;
  }
  const instruction = `Mode: reminders\nLanguage: ${input.data.language}\nBalances: ${JSON.stringify(
    balances,
  )}`;

  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const text = await generateText(instruction);
      const parsedJson: unknown = JSON.parse(text);
      const result = GenerateLedgerRemindersResponse.safeParse(parsedJson);
      if (!result.success) continue;

      const responseReminders = result.data.reminders;
      const valid =
        responseReminders.length === balances.length &&
        balances.every((balance) => {
          const reminder = responseReminders.find(
            (item) =>
              item.customer.trim().toLocaleLowerCase() ===
              balance.customer.trim().toLocaleLowerCase(),
          );
          return (
            reminder !== undefined &&
            reminder.amount_owed === balance.amount_owed &&
            containsExactAmount(reminder.message, balance.amount_owed) &&
            containsCustomer(reminder.message, balance.customer) &&
            !mentionsAnotherCustomer(
              reminder.message,
              reminder.customer,
              customerNames,
            )
          );
        });

      if (valid) {
        res.json(result.data);
        return;
      }
    } catch (error) {
      if (attempt === 1) {
        req.log.warn(
          {
            errorName: error instanceof Error ? error.name : "UnknownError",
            providerStatus: providerHttpStatus(error),
          },
          "Ledger reminder generation failed",
        );
      }
    }
  }

  res.json({
    reminders: balances.map((balance) => ({
      customer: balance.customer,
      amount_owed: balance.amount_owed,
      message: toFriendlyReminder(
        balance.customer,
        balance.amount_owed,
        input.data.language,
      ),
    })),
  });
});

logger.info({ model: GEMMA_MODEL }, "Ledger AI routes configured");

export default router;
