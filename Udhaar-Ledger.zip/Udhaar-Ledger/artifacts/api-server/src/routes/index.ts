import { Router, type IRouter } from "express";
import healthRouter from "./health";
import ledgerRouter from "./ledger";

const router: IRouter = Router();

router.use(healthRouter);
router.use(ledgerRouter);

export default router;
